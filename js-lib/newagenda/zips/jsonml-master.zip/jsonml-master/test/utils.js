window.onerror = function(msg, url, line) {
	alert([msg, url, line].join(', '));
};
